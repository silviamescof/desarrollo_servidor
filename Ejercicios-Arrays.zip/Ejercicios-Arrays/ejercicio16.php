<?php
/**
 * Ejercicio16.php
 * @author Silvia Mesa
 */
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    //tirada de un dado//
    
    $caras=array("img\\1.svg",".\Ejercicios-Arrays\img\2.svg",".\Ejercicios-Arrays\img\3.svg",".\Ejercicios-Arrays\img\4.svg",".\Ejercicios-Arrays\img\5.svg",".\Ejercicios-Arrays\img\6.svg");
    
    $aleatorio=random_int(0,5);
    echo $aleatorio;
    ?>

    <img src="<?php echo $caras[] ?>">  
    
</body>
</html>
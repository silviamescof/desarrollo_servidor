<?php
/**
 * Arrays ejercicio21.php
 *
 * @author Silvia Mesa Cofrades
 *
 */
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Elimina un animal.
    Arrays (1). Sin formularios.
    Silvia Mesa Cofrades
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="css/ejercicios_arrays.css" title="Color">
</head>

<body>
  <h1>Elimina un animal</h1>

  <p>Actualice la página para mostrar un nuevo grupo de animales.</p>

<?php
// D//E//C//L//A//R//A//C//I//O//N////D//E////V//A//R//I//A//B//L//E//S//

  $animales=array("ballena","caballito-mar","camello","cebra","elefante",
                  "hipopotamo","jirafa","leon","leopardo","medusa","mono",
                  "oso","oso-blanco","pajaro","pinguino","rinoceronte",
                  "serpiente","tigre","tortuga","tortuga-marina");

  $cuantosAnimales=random_int(20,30);
  $tablaValores=[];
  
  
  /////////////////////////C//A//L//C//U//L//O//S///////////////////////

  //BUCLE QUE CREA LOS VALORES A MOSTRAR EN UN ARRAY(FUNCIONA BBIEN//

  for($i=0;$i<=$cuantosAnimales;$i++){
    $tablaValores[]=$animales[random_int(0,count($animales)-1)];
  }
  
?>
<h1>
<p align="left">
  <?php
    echo $cuantosAnimales." Animales"."<br>";
  ?>
</p>
</h1>
<h1>
<?php
  //imprimir con ruta la primera tabla//
  
  for($i=0;$i<count($tablaValores)-1;$i++){
    echo '<img src="img/animales/'.$tablaValores[$i].'.svg" width="30" height="30" align="left"></img>';

  }
  echo "<br";
?>
</h1>
<br>
<p align="left">Animal eliminado
  <p>
  <?php
    $animalEliminado=$tablaValores[random_int(0,count($tablaValores)-1)];
    echo '<img src="img/animales/'.$animalEliminado.'.svg" width="30" height="30" align="left"></img>';
    echo "<br>";
    
  ?>
  </p>
  <p>
    <?php
       // BUCLE QUE RECORRE LA TABLA DE VALORES MOSTRADOS Y ELIMINA LAS OCURRENCIAS QUE COINCIDEN CON UN VALOR AL AZAHAR,
      for($i=0;$i<count($tablaValores)-1;$i++){
        if($animalEliminado===$tablaValores[$i]){
          unset($tablaValores[$i]);
        }
        $tablaValores = array_values($tablaValores);
      }
    ?>
  </p>
</p>
<p align="left">Quedan X
  <?php
   echo count($tablaValores)-1;
   ?>
   animales
  <p>
  <?php
  //imprimir con ruta la primera tabla//
  
    for($i=0;$i<count($tablaValores)-1;$i++){
        echo '<img src="img/animales/'.$tablaValores[$i].'.svg" width="30" height="30" align="left"></img>';
        
      }
      echo "<br";

?>
  </p>
</p>
  <footer>
    <p>Silvia Mesa Cofrades</p>
  </footer>
</body>
</html>

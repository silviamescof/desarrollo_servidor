<?php
/**
 * Arrays ejercicio20.php
 *
 * @author Silvia Mesa
 *
 */
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Partida de dados.
    Arrays (1). Sin formularios.
    Silvia Mesa
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="css/ejercicios_arrays.css" title="Color">
</head>

<body>
  <h1>Partida de dados</h1>

  <p>Actualice la página para mostrar una nueva partida de dados.</p>

<?php

   /////////////INICIALIZO VARIABLES//////////////////////////
   
   $numeroDados=random_int(2,7);
   $valoresJ1=[];
   $valoresJ2=[];
   $dadoJ1=random_int(1,6);
   $dadoJ2=random_int(1,6);
   $victoriasJ1=0;
   $victoriasJ2=0;
   $empates=0;
  echo '<h1><p align="left">Jugador 1</p></h1>';

   //*********tirada dados jugador uno*********//
   for($i=0;$i<$numeroDados;$i++){
      echo '<img src="./img/'.$dadoJ1.'.svg"></img>';
      $valoresJ1[]=$dadoJ1;
      $dadoJ1=random_int(1,6);
   }
   echo '<h1><p align="left">Jugador 2</p></h1>';

    //*********tirada dados jugador dos*******//
    for($i=0;$i<$numeroDados;$i++){
      echo '<img src="./img/'.$dadoJ2.'.svg"></img>';
      $valoresJ2[]=$dadoJ2;
      $dadoJ2=random_int(1,6);
   }

   //************conteo de resultados***********//
   for($i=0;$i<$numeroDados;$i++){
      if($valoresJ1[$i]>$valoresJ2[$i]){
        $victoriasJ1++;
      }elseif($valoresJ1[$i]==$valoresJ2[$i]){
        $empates++;
      }else{
        $victoriasJ2++;
      }
   }
   echo '<h1><p align="left">El jugador 1 ha ganado ' . $victoriasJ1 . ' veces. El jugador 2 ha ganado ' . $victoriasJ2 . ' veces y han empatado ' . $empates . ' veces.</p></h1>';

   if($victoriasJ1>$victoriasJ2){

    echo '<h1><p align="left"> En conjunto ha ganado el jugador 1 </p></h1>';

   }elseif($victoriasJ2>$victoriasJ1){

    echo '<h1><p align="left"> En conjunto ha ganado el jugador 2 </p></h1>';

   }else{

    echo '<h1><p align="left"> En conjunto han quedado empates </p></h1>';

   }
   ?>
   </body>
  <footer>
    <p>Silvia Mesa Cofrades </p>
  </footer>
</body>
</html>


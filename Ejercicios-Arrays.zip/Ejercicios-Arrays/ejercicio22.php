<?php
/**
 * Ejercicio 22. Cartas
 * @author Silvia Mesa
*/

    $numCartas=random_int(5,10);
    $arrayCartas=[];
    $cartaAlta=0;
    $cartaEliminada;
    $secondAlta=0;
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
  <title>
    Arrays (1). Sin formularios.
    Silvia Mesa Cofrades
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="css/ejercicios_arrays.css" title="Color">
</head>
<body>
    <h2>
   <?php
        for($i=0;$i<$numCartas;$i++){

            $arrayCartas[]=random_int(1,10);
    
            echo '<img src="img/cartas/t'.$arrayCartas[$i].'.svg " class="img_carta">';
    
            if($arrayCartas[$i]>$cartaAlta){
                $cartaAlta=$arrayCartas[$i];
            }
            
        }
        echo '<br>';
        echo '<h1>La carta mas alta es '.$cartaAlta.'</h1>';
        $cartaEliminada=$cartaAlta;
        echo '<h1>La carta a eliminar es </h1>';
        echo '<img src="img/cartas/t'.$cartaEliminada.'.svg " class="img_carta">';
        echo '<h1> Las cartas restantes</h1>';
        for($i=0;$i<count($arrayCartas)-1;$i++){
            if($arrayCartas[$i]==$cartaEliminada){
                unset($arrayCartas[$i]);
            }
        }
        $arrayCartas=array_values($arrayCartas);
        
        for($i=0;$i<count($arrayCartas)-1;$i++){
            echo '<img src="img/cartas/t'.$arrayCartas[$i].'.svg " class="img_carta">';
            if($arrayCartas[$i]>$secondAlta){
                $secondAlta=$arrayCartas[$i];
            }
        }

        echo '<h1>La carta mas alta ahora es '.$secondAlta.'</h1>';
        
   ?>
    </h2>
</body>
</html>